import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdicionaisPage } from './adicionais';

@NgModule({
  declarations: [
    AdicionaisPage,
  ],
  imports: [
    IonicPageModule.forChild(AdicionaisPage),
  ],
})
export class AdicionaisPageModule {}
