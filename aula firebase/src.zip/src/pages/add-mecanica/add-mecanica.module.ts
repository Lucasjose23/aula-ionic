import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddMecanicaPage } from './add-mecanica';

@NgModule({
  declarations: [
    AddMecanicaPage,
  ],
  imports: [
    IonicPageModule.forChild(AddMecanicaPage),
  ],
})
export class AddMecanicaPageModule {}
